
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Servlet implementation class GetArtistList
 */
@WebServlet("/GetArtistList")
public class GetArtistList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetArtistList() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("application/JSON");

		String band = "";

		if (request.getParameter("band") != null) {
			band = request.getParameter("band");
		}
		// TODO Auto-generated method stub
		JSONArray artistList = new JSONArray();

		try {
			DbUtilities db = new DbUtilities();

			String sql = "SELECT * FROM artist ";

			if (!band.equals("")) {
				sql += " where band LIKE '%" + band + "%' OR first_name LIKE '%" + band + "%' OR last_name LIKE '%"
						+ band + "%' ";
			}
			sql += "ORDER BY artist_id ASC";
			ResultSet rs = db.getResultSet(sql);
			while (rs.next()) {
				JSONObject artist = new JSONObject();
				artist.put("id", rs.getString("artist_id"));
				artist.put("firstName", rs.getString("first_name"));
				artist.put("lastName", rs.getString("last_name"));
				artist.put("band", rs.getString("band_name"));
				artist.put("bio", rs.getString("bio"));
				artistList.put(artist);

			}
		} catch (SQLException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(artistList.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
